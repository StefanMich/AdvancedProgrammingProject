#include "Node.h"
//A node in a binary tree

